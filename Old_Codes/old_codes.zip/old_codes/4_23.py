#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial


#Opening up the edited mask
mask_raw = Image.open('../BestMasks/Testing/spot3_0d_3_mask.tif')
mask = mask_raw.convert('RGB')#'L')
mask = np.asarray(mask)
'''
new = np.full((217,217),-1)

for i in range(0,len(mask)):
    for j in range(0,len(mask[0])):
        if (mask[i][j] == [255,255,255]).all():
            new[i][j] = 1
        elif (mask[i][j] == [255,0,0]).all():
            new[i][j] = 0
        elif (mask[i][j] == [0,0,255]).all():
            new[i][j] = 0

plt.imshow(new)
plt.colorbar()
plt.show()
'''
'''
test_mask = np.load('Training/Training_1_mask.npy')
plt.imshow(test_mask)
plt.colorbar()
plt.show()

new = np.full((217,217,3),0, dtype='uint8')

for i in range(0,len(test_mask)):
    for j in range(0,len(test_mask[0])):
        if test_mask[i][j] == 2:
            new[i][j] = [255,255,255]
        elif test_mask[i][j] == 0:
            new[i][j] = [255,0,0]
        elif test_mask[i][j] == 1:
            new[i][j] = [0,0,255]

im = Image.fromarray(new)
im.save("Training/Training_1_mask.tif")
'''
'''
plt.imshow(new)
plt.colorbar()
plt.show()
'''
