#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin,dilation
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial

image_raw = Image.open('crop1.png')
image = image_raw.convert('L')
image = np.asarray(image)
plt.imshow(image,cmap=plt.cm.gray)
plt.show()

new_image_raw = Image.open('data\crop45.tif')
new_image = new_image_raw.convert('L')
new_image = np.asarray(new_image)
plt.imshow(new_image,cmap=plt.cm.gray)
plt.show()

old_raw = Image.open('Skeletonize_unedited_layer.png')
old = old_raw.convert('L')
old = np.asarray(old)
#plt.imshow(old ,cmap=plt.cm.gray)
#plt.show()


old_interior = (old == 255)
old_boundary = (old <= 70)

new_old = np.full(old.shape, -1)
new_old[old_interior] = 1
new_old[old_boundary] = 0

#plt.imshow(new_old,cmap=plt.cm.gray )
#plt.show()

'''
new_old = np.zeros(old.shape)
new_old_ones = 0
new_old_zeros = 0 
for i in range(0,len(old)):
    for j in range(0,len(old[i])):
        if old[i][j] <= 100:
            new_old[i][j] = 1
            new_old_ones = new_old_ones + 1
        elif old[i][j] >= 245:
            new_old[i][j] = 0
            new_old_zeros = new_old_zeros + 1
        else:
            new_old[i][j] = -1

'''
mask_raw = Image.open('Edited_layer.png')
mask = mask_raw.convert('L')
mask = np.asarray(mask)
#plt.imshow(mask ,cmap=plt.cm.gray)
#plt.show()

mask_interior = (mask == 255)
mask_boundary = (mask <= 69)

new_mask = np.full(mask.shape, -1)
new_mask[mask_interior] = 1
new_mask[mask_boundary] = 0

#plt.imshow(new_mask ,cmap=plt.cm.gray)
#plt.show()

'''
new_mask = np.zeros(mask.shape)
new_mask_ones = 0
new_mask_zeros = 0 
for i in range(0,len(mask)):
    for j in range(0,len(mask[i])):
        if mask[i][j] <= 100:
            new_mask[i][j] = 1
            new_mask_ones = new_mask_ones + 1
        elif mask[i][j] >= 245:
            new_mask[i][j] = 0
            new_mask_zeros = new_mask_zeros + 1
        else:
            new_mask[i][j] = -1




def Jaccards(ground_truth, computer_made):
    TP = 0
    FP = 0
    FN = 0
    TN = 0
    for i in range(0,len(ground_truth)):
        for j in range(0,len(ground_truth[i])):
            if ground_truth[i][j] == 1 and computer_made[i][j] == 1:
                TP = TP + 1
            elif ground_truth[i][j] == 0 and computer_made[i][j] == 1:
                FP = FP + 1
            elif ground_truth[i][j] == 1 and computer_made[i][j] == 0:
                FN = FN + 1
            elif ground_truth[i][j] == 0 and computer_made[i][j] == 0:
                TN = TN + 1
 
    return TP / (TP + FN + FP)




print (Jaccards(new_mask,new_old))

'''

img = image

sigma_min = 1
sigma_max = 16
features_func = partial(feature.multiscale_basic_features,
                        intensity=True, edges=False, texture=True,
                        sigma_min=sigma_min, sigma_max=sigma_max)#multichannel = True)
features = features_func(img)
new_features = features_func(new_image)

clf = RandomForestClassifier(n_estimators=50, n_jobs=-1,
                             max_depth=10, max_samples=0.05)

new = new_mask.flatten() #new_mask.flatten()
new_img = np.reshape(features, (47089,15))

ind = (new > -1)
ind_ = (new == -1)

X_train = new_img[ind,:]
y_train = new[ind]


#og_shape = new_image.shape()
New_image = np.reshape(new_features, (-1,15))

clf.fit(X_train,y_train)

X_test = New_image #new_img[ind_,:]
y_test = clf.predict(X_test)

#remake_img = new
#remake_img[ind] = y_train
#remake_img[ind_] = y_test

#remake_img = np.reshape(remake_img, (217,217))
remake_img = np.reshape(y_test, new_image.shape)

values = np.unique(remake_img)

fig, ax = plt.subplots(1, 2, sharex=True, sharey=True, figsize=(9, 4))
ax[0].imshow(new_image ,cmap=plt.cm.gray)
#ax[0].contour(mask)
ax[0].set_title('Raw Image')
ax[1].imshow(remake_img , cmap=plt.cm.gray)
ax[1].set_title('Segmentation of crop45.tif')
fig.tight_layout()
plt.show()


#im = plt.imshow(remake_img , cmap=plt.cm.gray)
#plt.title('crop337.tif')
#bar = plt.colorbar(im)
#colors = [ im.cmap(im.norm(value)) for value in values]
#labels = ['Black: Boundary','White: Interior']
#patches = [ mpatches.Patch(color=colors[i], label="Level {l}".format(l=values[i])) for i in range(len(values)) ]
#plt.legend(["Black: Boundary","White: Interior"])#, bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0. )
#plt.show()

'''
clf = RandomForestClassifier(n_estimators=50, n_jobs=-1,
                             max_depth=10, max_samples=0.05)
clf = future.fit_segmenter(new_mask, features, clf)
result = future.predict_segmenter(features, clf)
'''
'''
fig, ax = plt.subplots(1, 2, sharex=True, sharey=True, figsize=(9, 4))
ax[0].imshow(new_mask ,cmap=plt.cm.gray)
#ax[0].contour(mask)
ax[0].set_title('Mask')
ax[1].imshow(remake_img , cmap=plt.cm.gray)
ax[1].set_title('Segmentation')
fig.tight_layout()
plt.show()

'''
