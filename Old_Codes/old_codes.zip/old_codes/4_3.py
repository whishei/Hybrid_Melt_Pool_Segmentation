#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial

#Opening the training data and the test data 

Image.MAX_IMAGE_PIXELS = 399279028
#Opening the training image
image_raw = Image.open('..\data\crop1.png')
image = image_raw.convert('L')
image = np.asarray(image)
#plt.imshow(image,cmap=plt.cm.gray)
#plt.show()

#Opening the second training image
new_image_raw = Image.open('..\data\crop88.tif')
new_image = new_image_raw.convert('L')
new_image = np.asarray(new_image)
#plt.imshow(new_image,cmap=plt.cm.gray)
#plt.show()

#Opening the third training image
train_raw = Image.open('..\data\crop45.tif')
new_train = train_raw.convert('L')
new_train = np.asarray(new_train)
#plt.imshow(new_image,cmap=plt.cm.gray)
#plt.show()


#Opening the fourth training image
train_raw2 = Image.open('..\data\crop393.tif')
new_train2 = train_raw2.convert('L')
new_train2 = np.asarray(new_train2)
#plt.imshow(new_train2,cmap=plt.cm.gray)
#plt.show()


my_dpi = 3600
'''
#Opening the test image
test_image_raw = Image.open('..\data\Largecrop_2.tif')
test_image = test_image_raw.convert('L')
test_image = np.asarray(test_image)
plt.figure(dpi = 3600)
#plt.figure(figsize=(test_image.shape[0],test_image.shape[1]), dpi=my_dpi)
#plt.imshow(test_image,cmap=plt.cm.gray)
#plt.axis('off')
#plt.savefig('Total_Test.eps', bbox_inches='tight', pad_inches=0)#, dpi = 1000) #
#plt.show()
#test_image = np.asarray(test_image)
#plt.imshow(test_image,cmap=plt.cm.gray)
#plt.show()
'''
#Opening up the edited mask
mask_raw = Image.open('..\BestMasks\crop1_bestmask.png')
mask = mask_raw.convert('L')
mask = np.asarray(mask)


#Opening up the edited mas
crop88_mask_raw = Image.open('..\BestMasks\crop88_bestmask.png')
crop88_mask = crop88_mask_raw.convert('L')
crop88_mask = np.asarray(crop88_mask)
#plt.imshow(crop88_mask ,cmap=plt.cm.gray)
#plt.show()


#Opening up the edited mask
train_mask_raw = Image.open('New.png')
train_mask = train_mask_raw.convert('L')
train_mask = np.asarray(train_mask)
plt.imshow(train_mask ,cmap=plt.cm.gray)
plt.show()


#Opening up the edited mask
train_mask_raw2 = Image.open('crop393_edited.png')
train_mask2 = train_mask_raw2.convert('L')
train_mask2 = np.asarray(train_mask2)
#plt.imshow(train_mask2 ,cmap=plt.cm.gray)
#plt.show()


#Creating the first training mask
mask_interior = (mask == 255)
mask_boundary = (mask == 0)

new_mask = np.full(mask.shape, -1)
new_mask[mask_interior] = 2 #255
new_mask[mask_boundary] = 0

#plt.imshow(new_mask ,cmap=plt.cm.gray)
#plt.colorbar()
#plt.show()



#Creating the second training mask
crop88_mask_interior = (crop88_mask == 255)
crop88_mask_boundary = (crop88_mask == 0)
crop88_mask_80 = (crop88_mask <= 125)
crop88_mask_75 = (crop88_mask >= 110)
crop88_mask_other = np.logical_and(crop88_mask_80,crop88_mask_75)

new_crop88_mask = np.full(crop88_mask.shape, -1)
new_crop88_mask[crop88_mask_other] = 1 #119
new_crop88_mask[crop88_mask_interior] = 2 #255
new_crop88_mask[crop88_mask_boundary] = 0

# np.count_nonzero(a < 4) How to visualize to check

#Visualization check 
plt.imshow(new_crop88_mask ,cmap=plt.cm.gray)
plt.colorbar()
plt.show()


#Creating the second training mask
train_mask_interior = (train_mask == 255)
train_mask_boundary = (train_mask == 0)
train_mask_80 = (train_mask <= 140)
train_mask_75 = (train_mask >= 130)
train_mask_other = np.logical_and(train_mask_80,train_mask_75)

new_train_mask = np.full(train_mask.shape, -1)
new_train_mask[train_mask_other] = 1 #119
new_train_mask[train_mask_interior] = 2 #255
new_train_mask[train_mask_boundary] = 0

# np.count_nonzero(a < 4) How to visualize to check

#Visualization check 
plt.imshow(new_train_mask ,cmap=plt.cm.gray)
plt.colorbar()
plt.show()


#Creating the second training mask
train_mask2_interior = (train_mask2 == 255)
train_mask2_boundary = (train_mask2 == 0)
train_mask2_80 = (train_mask2 <= 130)
train_mask2_75 = (train_mask2 >= 110)
train_mask2_other = np.logical_and(train_mask2_80,train_mask2_75)

new_train_mask2 = np.full(train_mask2.shape, -1)
new_train_mask2[train_mask2_other] = 1 #119
new_train_mask2[train_mask2_interior] = 2 #255
new_train_mask2[train_mask2_boundary] = 0

# np.count_nonzero(a < 4) How to visualize to check

#Visualization check 
plt.imshow(new_train_mask2 ,cmap=plt.cm.gray)
plt.colorbar()
plt.show()

np.save('Training_1_mask.npy', new_mask)
np.save('Training_2_mask.npy', new_crop88_mask)
np.save('Training_3_mask.npy', new_train_mask)
np.save('Training_4_mask.npy', new_train_mask2)


#Uncomment to test accuracy of created mask using Jaccards calculation 
'''
#Opening the skeletonized mask
old_raw = Image.open('Skeletonize_unedited_layer.png')
old = old_raw.convert('L')
old = np.asarray(old)
#plt.imshow(old ,cmap=plt.cm.gray)
#plt.show()

old_interior = (old == 255)
old_boundary = (old <= 70)

new_old = np.full(old.shape, -1)
new_old[old_interior] = 1
new_old[old_boundary] = 0

#plt.imshow(new_old,cmap=plt.cm.gray )
#plt.show()

def Jaccards(ground_truth, computer_made):
    TP = 0
    FP = 0
    FN = 0
    TN = 0
    for i in range(0,len(ground_truth)):
        for j in range(0,len(ground_truth[i])):
            if ground_truth[i][j] == 1 and computer_made[i][j] == 1:
                TP = TP + 1
            elif ground_truth[i][j] == 0 and computer_made[i][j] == 1:
                FP = FP + 1
            elif ground_truth[i][j] == 1 and computer_made[i][j] == 0:
                FN = FN + 1
            elif ground_truth[i][j] == 0 and computer_made[i][j] == 0:
                TN = TN + 1
 
    return TP / (TP + FN + FP)


print (Jaccards(new_mask,new_old))

'''

'''
#############Random Forest Classifier

sigma_min = 1
sigma_max = 16
features_func = partial(feature.multiscale_basic_features,
                        intensity=True, edges=False, texture=True,
                        sigma_min=sigma_min, sigma_max=sigma_max)#multichannel = True)

#Features for the two training images
train1 = image
train2 = new_image
train3 = new_train
train4 = new_train2
train1_features = features_func(train1)
train2_features = features_func(train2)
train3_features = features_func(train3)
train4_features = features_func(train4)

#Features for the test image
test_features = features_func(test_image)


clf = RandomForestClassifier(n_estimators=50, n_jobs=-1,
                             max_depth=10, max_samples=0.05)

#Reshaping from mXm array to (mxm)x1 array
train1_mask = new_mask.reshape(-1) 
train2_mask = new_crop88_mask.reshape(-1) 
train3_mask = new_train_mask.reshape(-1)
train4_mask = new_train_mask2.reshape(-1)

#Reshaping from mxmx15 to (mxm)x15 array
train1_features_ = np.reshape(train1_features, (-1,train1_features.shape[2]))
train2_features_ = np.reshape(train2_features, (-1,train2_features.shape[2]))
train3_features_ = np.reshape(train3_features, (-1,train3_features.shape[2]))
train4_features_ = np.reshape(train4_features, (-1,train4_features.shape[2]))
print ("HERE1")
TEST_image = np.reshape(test_features, (-1,test_features.shape[2]))
print ("HERE2")

#Choosing only the known and labeled pixels
ind1 = (train1_mask > -1)
ind2 = (train2_mask > -1)
ind3 = (train3_mask > -1)
ind4 = (train4_mask > -1)
#Choosing only the unknown and unlabeled pixels
ind1_ = (train1_mask == -1)
ind2_ = (train2_mask == -1)
ind3_ = (train3_mask == -1)
ind4_ = (train4_mask == -1)


#Creating the training data 
X_train1 = train1_features_[ind1,:]
X_train2 = train2_features_[ind2,:]
X_train3 = train3_features_[ind3,:]
X_train4 = train4_features_[ind4,:]
y_train1 = train1_mask[ind1]
y_train2 = train2_mask[ind2]
y_train3 = train3_mask[ind3]
y_train4 = train4_mask[ind4]
X_train = np.append(X_train1,X_train2,axis = 0)
X_train = np.append(X_train,X_train3,axis = 0)
X_train = np.append(X_train,X_train4,axis = 0)
y_train = np.append(y_train1,y_train2)
y_train = np.append(y_train,y_train3)
y_train = np.append(y_train,y_train4)


clf.fit(X_train,y_train)
print ("HERE3")
#Testing our classifier on our test data
X_test = TEST_image 
y_test = clf.predict(X_test)


#Needed for correct visualization
my_dpi = 3600


#Reshaping back into orginal image shape
remake_img = np.reshape(y_test, test_image.shape)


#Unique classifications (0 - boundary, 1 - background, 2 - interior)
values = np.unique(remake_img)
print ("HERE4")

#Visualization
fig, ax = plt.subplots(1, 2, sharex=True, sharey=True, figsize=(9, 4))
ax[0].imshow(test_image,cmap=plt.cm.gray)
ax[0].set_title('Raw Image')
ax[1].imshow(remake_img, cmap=plt.cm.gray)
ax[1].set_title('Segmentation of Test1.tif')
fig.tight_layout()
#plt.savefig('Test2_2_1', bbox_inches='tight', pad_inches=0)
plt.show()
plt.figure(dpi = my_dpi)
#plt.figure(figsize=(test_image.shape[0],test_image.shape[1]), dpi=my_dpi)#(4452/my_dpi, 19589/my_dpi), dpi=my_dpi)
plt.imshow(remake_img,cmap=plt.cm.gray)
plt.axis('off')
plt.savefig('NEWTESTTEST.eps', bbox_inches='tight', pad_inches=0)#, dpi = 1000)
plt.show()

#np.save('Test1_good.npy',remake_img)
#np.save('Bottom_Full.npy',remake_img)
'''
'''
#thresh_value = skimage.filters.threshold_otsu(remake_img)
thresh = remake_img > 1 #thresh_value
#fill = ndi.binary_closing(thresh)
fill = ndi.binary_fill_holes(thresh)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
plt.savefig('TestingThresholds\Fill.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''

'''
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(remake_img,cmap=plt.cm.gray)
plt.axis('off')
plt.savefig('TestingThresholds\crop228_1.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
'''
#thresh_value = skimage.filters.threshold_yen(remake_img)
thresh = remake_img > 1 #thresh_value
fill = ndi.binary_closing(thresh)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('TestingThresholds\Closing.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
'''
# noise removal
blurred = ndi.gaussian_filter(remake_img,sigma=0.25)#fill, sigma=0.25)
result = hessian(blurred,black_ridges=0,sigmas=1)

# thresholding
threshold = skimage.filters.threshold_otsu(blurred)
binary_image = blurred <= threshold
binary_image = invert(binary_image)

# result visualization
plt.figure(figsize=(test_image.shape[0]/my_dpi,test_image.shape[1]/my_dpi), dpi=my_dpi)#(4452/my_dpi, 19589/my_dpi), dpi=my_dpi)
plt.imshow(binary_image,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Gaus.png', bbox_inches='tight', pad_inches=0)#, dpi = 1000)
plt.show()





for i in range (0,2):
    dilate = dilation(erode,element2)
    plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
    plt.imshow(dilate,cmap=plt.cm.gray)
    plt.axis('off')
    name = 'new_' + str(i+2) + '.png'
    plt.savefig(name, bbox_inches='tight', pad_inches=0)
    plt.show()
    erode = dilate


#thresh_value = skimage.filters.threshold_otsu(binary_image)
thresh = binary_image > 0 #thresh_value
fill = ndi.binary_fill_holes(thresh)
plt.figure(figsize=(test_image.shape[0]/my_dpi,test_image.shape[1]/my_dpi), dpi=my_dpi)#figsize=(4452/my_dpi, 19589/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Fill.png', bbox_inches='tight', pad_inches=0)#, dpi = 1000)
plt.show()

fill = fill.astype('int')
interiors = fill == 1
fill[interiors] = 2

element = np.array([[1,0,1],[0,0,0],[1,0,1]]) #[[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])
element2 = np.array([[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])

element3 = np.array([[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])

dilate = dilation(fill,element)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(dilate,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Dilate1.png', bbox_inches='tight', pad_inches=0)
plt.show()

#skeleton = skeletonize(fill,method='lee')
erode = erosion(fill,element2)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(erosion(fill,element2),cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Dilate3.png', bbox_inches='tight', pad_inches=0)
plt.show()

#np.save('Test1_better.npy',fill)
'''
'''
fill = fill.astype('int')
interiors = fill == 1
fill[interiors] = 2

outside = remake_img == 1
fill[outside] = 1
plt.figure(figsize=(test_image.shape[0]/my_dpi,test_image.shape[1]/my_dpi), dpi=my_dpi)#figsize=(4452/my_dpi, 19589/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('CurrentOutput\Seg_mask.png', bbox_inches='tight', pad_inches=0)#, dpi = 1000)
plt.show()

'''

'''
thresh_value = skimage.filters.threshold_triangle(remake_img)
thresh = remake_img > 1 #thresh_value
fill = ndi.binary_fill_holes(thresh)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
plt.savefig('TestingThresholds\Triangle.png', bbox_inches='tight', pad_inches=0)
plt.show()

'''

#Trying to clean image for better contours 

'''

fill = skimage.morphology.remove_small_objects(fill)#binary_image)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#lt.savefig('Testing.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''


#Currently Working on - new segmentation 
#im = remake_img

'''
im = fill

distance = ndi.distance_transform_edt(im)
coords = peak_local_max(distance, footprint=np.ones((10, 10)), labels=im)

mask = np.zeros(distance.shape, dtype=bool)
mask[tuple(coords.T)] = True
markers, _ = ndi.label(mask)

#labels = skimage.segmentation.random_walker(im,markers)
labels = skimage.segmentation.watershed(-distance,markers,mask=im)
contours = skimage.measure.find_contours(labels, 1)
#plt.imshow(contours)
#plt.show()

#plt.imshow(image_raw)
#plt.show()
#f = plt.figure()
#f.set_figwidth(width)
#f.set_figheight(height)

#plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#plt.imshow(remake_img,cmap=plt.cm.gray)
#plt.axis('off')
#plt.savefig('out.png', bbox_inches='tight', pad_inches=0)
#plt.show()

print ("HERE")
fig,ax = plt.subplots(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#ax.imshow(image_raw,cmap = plt.cm.gray)
for contour in contours:
    #ax.plot(contour[0, 1], contour[0, 0],linewidth=1,color='r')
    #ax.plot(contour[1, 1], contour[1, 0],linewidth=1,color='blue')
    ax.plot(contour[:, 1], contour[:, 0],linewidth=2)#,color='r')
#ax.plot(contours[100][:,1], contours[100][:,0],linewidth=2,color='blue')
ax.axis('off')
plt.savefig('TestingThresholds\crop228_4.png', bbox_inches='tight', pad_inches=0)
#plt.show())
plt.show()
#plt.imshow(contours)
print ("DONE")
#plt.show()

'''

