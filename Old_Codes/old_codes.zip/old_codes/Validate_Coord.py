import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing, opening,erosion
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial

man_seg = [[1,0,1,0],[1,0,1,1],[1,1,0,1],[0,0,1,0]]
man_seg = np.array(man_seg)

plt.imshow(man_seg,cmap = plt.cm.gray)
plt.colorbar()
plt.show()


#Horizontal Coord Lengths
coords = []
for i in range(0,len(man_seg)):
    length = 0
    for j in range(0,len(man_seg[i])):
        if man_seg[i][j] == 1: #== man_seg[i][j+1]:
            length = length + 1
            if j == len(man_seg[i]) - 1:
                coords.append(length)
        else:
            if length != 0:
                coords.append(length)
            length = 0

plt.title('Horizontal Coord Lengths of crop45_manseg')
plt.hist(coords)
#plt.savefig('crop45_man_h.png', bbox_inches='tight', pad_inches=0)
plt.show()


#Vertical Coord Lengths
man_seg = man_seg.T
print (man_seg)
coords = []
for i in range(0,len(man_seg)):
    length = 0
    for j in range(0,len(man_seg[i])):
        if man_seg[i][j] == 1: #== man_seg[i][j+1]:
            length = length + 1
            if j == len(man_seg[i]) - 1:
                coords.append(length)
        else:
            if length != 0:
                coords.append(length)
            length = 0
            
plt.title('Vertical Coord Lengths of crop45_manseg')
plt.hist(coords,100)
#plt.savefig('crop45_ver_h.png', bbox_inches='tight', pad_inches=0)
plt.show()

