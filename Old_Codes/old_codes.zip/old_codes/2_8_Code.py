#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial

#Opening the training data and the test data 


#Opening the training image
image_raw = Image.open('crop1.png')
image = image_raw.convert('L')
image = np.asarray(image)
#plt.imshow(image,cmap=plt.cm.gray)
#plt.show()

#Opening the second training image
new_image_raw = Image.open('data\crop88.tif')
new_image = new_image_raw.convert('L')
new_image = np.asarray(new_image)
#plt.imshow(new_image,cmap=plt.cm.gray)
#plt.show()

#Opening the test image
test_image_raw = Image.open('data\crop45.tif')
test_image = test_image_raw.convert('L')
test_image = np.asarray(test_image)
#plt.imshow(test_image,cmap=plt.cm.gray)
#plt.show()

#Opening up the edited mask
mask_raw = Image.open('newcrop.png')
mask = mask_raw.convert('L')
mask = np.asarray(mask)
#plt.imshow(mask ,cmap=plt.cm.gray)
#plt.show()

#Opening up the edited mask
crop88_mask_raw = Image.open('crop_88_edited.png')
crop88_mask = crop88_mask_raw.convert('L')
crop88_mask = np.asarray(crop88_mask)
#plt.imshow(crop88_mask ,cmap=plt.cm.gray)
#plt.show()



#Creating the first training mask
mask_interior = (mask == 255)
mask_boundary = (mask == 0)

new_mask = np.full(mask.shape, -1)
new_mask[mask_interior] = 2 #255
new_mask[mask_boundary] = 0


#Creating the second training mask
crop88_mask_interior = (crop88_mask == 255)
crop88_mask_boundary = (crop88_mask == 0)
crop88_mask_80 = (crop88_mask <= 125)
crop88_mask_75 = (crop88_mask >= 110)
crop88_mask_other = np.logical_and(crop88_mask_80,crop88_mask_75)

new_crop88_mask = np.full(crop88_mask.shape, -1)
new_crop88_mask[crop88_mask_other] = 1 #119
new_crop88_mask[crop88_mask_interior] = 2 #255
new_crop88_mask[crop88_mask_boundary] = 0

# np.count_nonzero(a < 4) How to visualize to check

#Visualization check 
#plt.imshow(new_crop88_mask ,cmap=plt.cm.gray)
#plt.colorbar()
#plt.show()



#Uncomment to test accuracy of created mask using Jaccards calculation 
'''
#Opening the skeletonized mask
old_raw = Image.open('Skeletonize_unedited_layer.png')
old = old_raw.convert('L')
old = np.asarray(old)
#plt.imshow(old ,cmap=plt.cm.gray)
#plt.show()

old_interior = (old == 255)
old_boundary = (old <= 70)

new_old = np.full(old.shape, -1)
new_old[old_interior] = 1
new_old[old_boundary] = 0

#plt.imshow(new_old,cmap=plt.cm.gray )
#plt.show()

def Jaccards(ground_truth, computer_made):
    TP = 0
    FP = 0
    FN = 0
    TN = 0
    for i in range(0,len(ground_truth)):
        for j in range(0,len(ground_truth[i])):
            if ground_truth[i][j] == 1 and computer_made[i][j] == 1:
                TP = TP + 1
            elif ground_truth[i][j] == 0 and computer_made[i][j] == 1:
                FP = FP + 1
            elif ground_truth[i][j] == 1 and computer_made[i][j] == 0:
                FN = FN + 1
            elif ground_truth[i][j] == 0 and computer_made[i][j] == 0:
                TN = TN + 1
 
    return TP / (TP + FN + FP)


print (Jaccards(new_mask,new_old))

'''

#############Random Forest Classifier

sigma_min = 1
sigma_max = 16
features_func = partial(feature.multiscale_basic_features,
                        intensity=True, edges=False, texture=True,
                        sigma_min=sigma_min, sigma_max=sigma_max)#multichannel = True)

#Features for the two training images
features = features_func(image)
new_features = features_func(new_image)

#Features for the test image
test_features = features_func(test_image)


clf = RandomForestClassifier(n_estimators=50, n_jobs=-1,
                             max_depth=10, max_samples=0.05)

#Reshaping from mXm array to (mxm)x1 array
new = new_mask.reshape(-1) 
new2 = new_crop88_mask.reshape(-1) 

#Reshaping from mxmx15 to (mxm)x15 array
new_img = np.reshape(features, (-1,features.shape[2]))
new_img2 = np.reshape(new_features, (-1,new_features.shape[2]))
TEST_image = np.reshape(test_features, (-1,test_features.shape[2]))

#Choosing only the known and labeled pixels
ind1 = (new > -1)
ind2 = (new2 > -1)
#Choosing only the unknown and unlabeled pixels
ind1_ = (new == -1)
ind2_ = (new2 == -1)

#Creating the training data 
X_train1 = new_img[ind1,:]
X_train2 = new_img2[ind2,:]
y_train1 = new[ind1]
y_train2 = new2[ind2]
X_train = np.append(X_train1,X_train2,axis = 0)
y_train = np.append(y_train1,y_train2)


clf.fit(X_train,y_train)

#Testing our classifier on our test data
X_test = TEST_image 
y_test = clf.predict(X_test)


#Needed for correct visualization
my_dpi = 96


#Reshaping back into orginal image shape
remake_img = np.reshape(y_test, test_image.shape)


#Unique classifications (0 - boundary, 1 - background, 2 - interior)
values = np.unique(remake_img)


#Visualization
'''
fig, ax = plt.subplots(1, 2, sharex=True, sharey=True, figsize=(9, 4))
ax[0].imshow(test_image,cmap=plt.cm.gray)
ax[0].set_title('Raw Image')
ax[1].imshow(remake_img, cmap=plt.cm.gray)
ax[1].set_title('Segmentation of crop45.tif')
fig.tight_layout()
plt.savefig('Testing.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''

plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(remake_img,cmap=plt.cm.gray)
plt.axis('off')
#lt.savefig('Testing.png', bbox_inches='tight', pad_inches=0)
plt.show()



thresh_value = skimage.filters.threshold_otsu(remake_img)
thresh = remake_img > thresh_value
fill = ndi.binary_fill_holes(thresh)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#lt.savefig('Testing.png', bbox_inches='tight', pad_inches=0)
plt.show()



'''
skeleton = skeletonize(invert(fill))#,method='lee')
im = invert(skeleton)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(im,cmap=plt.cm.gray)
plt.axis('off')
#lt.savefig('Testing.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
'''
fill = skimage.morphology.remove_small_objects(fill)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#lt.savefig('Testing.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''


#Currently Working on - new segmentation 
#im = remake_img


im = fill

distance = ndi.distance_transform_edt(im)
coords = peak_local_max(distance, footprint=np.ones((10, 10)), labels=im)

mask = np.zeros(distance.shape, dtype=bool)
mask[tuple(coords.T)] = True
markers, _ = ndi.label(mask)

labels = skimage.segmentation.random_walker(im,markers)
#labels = skimage.segmentation.watershed(-distance,markers,mask=im)
contours = skimage.measure.find_contours(labels, 1)
#plt.imshow(contours)
#plt.show()

#plt.imshow(image_raw)
#plt.show()
#f = plt.figure()
#f.set_figwidth(width)
#f.set_figheight(height)

#plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#plt.imshow(remake_img,cmap=plt.cm.gray)
#plt.axis('off')
#plt.savefig('out.png', bbox_inches='tight', pad_inches=0)
#plt.show()

print ("HERE")
fig,ax = plt.subplots(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#ax.imshow(image_raw,cmap = plt.cm.gray)
for contour in contours:
    #ax.plot(contour[0, 1], contour[0, 0],linewidth=1,color='r')
    #ax.plot(contour[1, 1], contour[1, 0],linewidth=1,color='blue')
    ax.plot(contour[:, 1], contour[:, 0],linewidth=2)#,color='r')
#ax.plot(contours[100][:,1], contours[100][:,0],linewidth=2,color='blue')
ax.axis('off')
plt.savefig('Testing_new.png', bbox_inches='tight', pad_inches=0)
#plt.show())
plt.show()
#plt.imshow(contours)
print ("DONE")
#plt.show()





