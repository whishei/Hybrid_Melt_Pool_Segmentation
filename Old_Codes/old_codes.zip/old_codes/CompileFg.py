# -*- coding: utf-8 -*-
"""
Created on Fri Mar 10 14:02:07 2023

@author: sheilaw
"""

#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial
import seaborn as sns


top = np.load('Top_4.npy')
middle = np.load('Middle_4.npy')
bottom = np.load('Bottom_4.npy')

new = np.concatenate((top,middle), axis=0)
new = np.concatenate((new,bottom), axis=0)

new = new.astype('uint8')
my_dpi = 3600

plt.figure(dpi=my_dpi)
plt.imshow(new,cmap=plt.cm.gray)
plt.axis('off')
plt.savefig('NEWFULLIMAGE2.eps', bbox_inches='tight', pad_inches=0)
#plt.show()
