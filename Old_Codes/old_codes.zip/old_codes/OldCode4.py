#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin,dilation
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches


from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial

#Opening the training image
image_raw = Image.open('NEW_TRAIN.png')
image = image_raw.convert('L')
image = np.asarray(image)
plt.imshow(image,cmap=plt.cm.gray)
plt.show()
