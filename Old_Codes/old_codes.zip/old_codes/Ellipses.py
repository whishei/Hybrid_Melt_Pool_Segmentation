
#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial
import seaborn as sns

from skimage import data, color, img_as_ubyte
from skimage.feature import canny
from skimage.transform import hough_ellipse
from skimage.draw import ellipse_perimeter

import cv2 as cv
import scipy.ndimage as ndimage   


new_image_raw1 = Image.open('Files/Test1_Edits.png')
new_image1 = new_image_raw1.convert('L')
new_image1 = np.asarray(new_image1)

new_image_raw2 = Image.open('Files/Test1.png')
new_image2 = new_image_raw2.convert('L')
new_image2 = np.asarray(new_image2)


test_image_raw = Image.open('Files/Test1_OG.png')
test_image = test_image_raw.convert('L')
test_image = np.asarray(test_image)

#Creating the second training mask
new_image1_interior = (new_image1 >= 240)
new_image1_boundary = (new_image1 <= 20)
new_image1_80 = (new_image1 <= 140)
new_image1_75 = (new_image1 >= 120)
new_image1_other = np.logical_and(new_image1_80,new_image1_75)

new_image1_mask = np.full(new_image1.shape, 0)
new_image1_mask[new_image1_other] = 1 #119
new_image1_mask[new_image1_interior] = 2 #255
new_image1_mask[new_image1_boundary] = 0

plt.imshow(new_image1_mask, cmap=plt.cm.gray) 
plt.colorbar()
#plt.savefig('BADISH.png')
plt.show()





#Creating the second training mask
new_image2_interior = (new_image2 >= 240)
new_image2_boundary = (new_image2 <= 20)
new_image2_80 = (new_image2 <= 140)
new_image2_75 = (new_image2 >= 120)
new_image2_other = np.logical_and(new_image2_80,new_image2_75)

new_image2_mask = np.full(new_image2.shape, 0)
new_image2_mask[new_image2_other] = 1 #119
new_image2_mask[new_image2_interior] = 2 #255
new_image2_mask[new_image2_boundary] = 0


plt.imshow(new_image2_mask, cmap=plt.cm.gray) 
plt.colorbar()
#plt.savefig('BADISH.png')
plt.show()


array = np.load('..\manually_seg_regions\crop45_seg.npy',allow_pickle = True).item()

#centers = np.load('Centers.npy')
#man_centers = np.load('crop_45_centers.npy')
#new_contours = np.load('Contours.npy',allow_pickle = True)#.item()


outlines = array['outlines']
colors = array['colors']
masks = array['masks']
chan_choose = array['chan_choose']
img = array['img']
filename = array['filename']
flows = array['ismanual']
manual_changes = array['manual_changes']
model_path = array['model_path']
flow_threshold = array['flow_threshold']
cellprob_threshold = array['cellprob_threshold']


#test_image_raw = Image.open('..\data\crop45.tif')
#test_image = test_image_raw.convert('L')
#test_image = np.asarray(test_image)
'''
areas = []
asp = []
cell_threshold = 10
mask = masks
for i in range(1,mask.max()+1):
  cell_mask=mask==i
  n_px=cell_mask.sum()
  cell_mask1=cell_mask*255
  i_cont, hierarchy = cv.findContours(cell_mask1,2,1)
  cont=max(i_cont, key=len)
  cont=cont.reshape(-1,2)
  if len(cont)>=cell_threshold:
    print("cell_"+str(i), "area" + str(n_px))#,"contour" + str(cont))
    areas.append(n_px)
    ellipse = cv.fitEllipse(cont)
    asp.append(ellipse[1][1]/ellipse[1][0])
    cv.ellipse(test_image,ellipse, (0,0,255), 3)

plt.imshow(test_image)
plt.show()

'''
newarray = new_image2_mask
#test_image = 
#np.load('SAVETHIS.npy')
#plt.imshow(newarray, cmap=plt.cm.gray) 
#plt.savefig('BAD.png')
#plt.show()

im = newarray
distance = ndi.distance_transform_edt(im)
coords = peak_local_max(distance, footprint=np.ones((10, 10)), labels=im)

mask = np.zeros(distance.shape, dtype=bool)
mask[tuple(coords.T)] = True
markers, _ = ndi.label(mask)

#labels = skimage.segmentation.random_walker(im,markers)
labels = skimage.segmentation.watershed(-distance,markers,mask=im)
contours = skimage.measure.find_contours(labels, 3)



'''
my_dpi = 96
#print ("HERE")
fig,ax = plt.subplots(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#ellipses = []
#plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#ax.imshow(image_raw,cmap = plt.cm.gray)
for contour in contours:
    #ax.plot(contour[0, 1], contour[0, 0],linewidth=1,color='r')
    #ax.plot(contour[1, 1], contour[1, 0],linewidth=1,color='blue')
    ax.plot(contour[:, 1], contour[:, 0],linewidth=2)#,color='r')
    #ellipse = cv.fitEllipse(contour)
#ax.plot(contours[100][:,1], contours[100][:,0],linewidth=2,color='blue')
ax.axis('off')
#plt.savefig('TestingThresholds\crop228_4.png', bbox_inches='tight', pad_inches=0)
#plt.show())
plt.show()
#plt.imshow(contours)
#print ("DONE")
#plt.show()


'''



#new_contours = []
blank = np.full_like(newarray,0)
for i in range(0,len(contours)):
    mask = (np.rint(contours[i])).astype(int)
    if len(mask) >= 10:
        blank[mask[:,0],mask[:,1]] = i
    #new_contours.append(blank)
    
    
    


areas = []
asp = []
cell_threshold = 10
mask = blank#new_contours
for i in range(1,mask.max()+1):
  cell_mask=mask==i
  n_px=cell_mask.sum()
  cell_mask1=cell_mask*255
  i_cont, hierarchy = cv.findContours(cell_mask1,2,1)
  if i_cont != ():
      cont=max(i_cont, key=len)
      cont=cont.reshape(-1,2)
      if len(cont)>=cell_threshold:
        #print("cell_"+str(i), "area" + str(n_px))#,"contour" + str(cont))
        areas.append(n_px)
        ellipse = cv.fitEllipse(cont)
        #print (ellipse)
        asp.append((ellipse[1][1]+1)/(ellipse[1][0]+1))
        cv.ellipse(test_image,ellipse, (0,0,255), 3)

plt.imshow(test_image)
plt.savefig('TEST_Ellipse2.png')
plt.show()
'''
#cv.imshow(test_image)
#plt.show()
vals, edges = np.histogram(areas,50,range = [0,50])

#middle = []
num = []
for i in range(0,len(edges)-1):
    middle = (edges[i]+ edges[i+1])/2 
    num.append(middle)

plt.hist(vals,bins = num)
#plt.plot(num,vals)
plt.show()
'''
#cv.Color(test_img, gray, cv::COLOR_BGR2GRAY)

'''
array = np.load('SAVETHIS.npy')

ind1 = array == 1
array[ind1] = 0
plt.imshow(test_image)#,cmap =plt.cm.gray)
plt.show()

img = Image.fromarray(array, 'L')
#im = array
img = np.array(img)
thresh, im_bw = cv.threshold(img, 0, 2, cv.THRESH_BINARY) #im_bw: binary image
contours, im3= cv.findContours(im_bw,cv.RETR_TREE , cv.CHAIN_APPROX_NONE)
for i in range(0,len(contours)):
    if cv.contourArea(contours[i]) > 10:
        print ("HERE")
        cv.drawContours(test_image, contours[i], 0, (0,255,0), 1)#thickness=cv.FILLED)
plt.imshow(test_image)#,cmap='gray')
plt.show()
'''



'''
#edged = cv.Canny(array, 0, 2)
contours,_ = cv.findContours(array ,2,1)
ellipses = []

cv.drawContours(test_image,contours,-1,(0,0,255), thickness=cv.FILLED)

for i in range(0,200): #len(contours)):
    if len(contours[i]) >= 5:
        ellipse =cv.fitEllipse(contours[i])
        cv.ellipse(test_image,ellipse, (0,0,255), 3)

plt.imshow(test_image)
plt.show()
#cv.drawContours(test_image, contours, -1,(0,255,0), 3)
#plt.show()





'''







'''
im = new_image1_mask
distance = ndi.distance_transform_edt(im)
coords = peak_local_max(distance, footprint=np.ones((10, 10)), labels=im)

mask = np.zeros(distance.shape, dtype=bool)
mask[tuple(coords.T)] = True
markers, _ = ndi.label(mask)

#labels = skimage.segmentation.random_walker(im,markers)
labels = skimage.segmentation.watershed(-distance,markers,mask=im)
contours = skimage.measure.find_contours(labels, 1)
#plt.imshow(contours)
#plt.show()
'''
#plt.imshow(image_raw)
#plt.show()
#f = plt.figure()
#f.set_figwidth(width)
#f.set_figheight(height)

#plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#plt.imshow(remake_img,cmap=plt.cm.gray)
#plt.axis('off')
#plt.savefig('out.png', bbox_inches='tight', pad_inches=0)
#plt.show()


#my_dpi = 96
#print ("HERE")
#fig,ax = plt.subplots(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#ellipses = []
#plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#ax.imshow(image_raw,cmap = plt.cm.gray)
#for contour in contours:
    #ax.plot(contour[0, 1], contour[0, 0],linewidth=1,color='r')
    #ax.plot(contour[1, 1], contour[1, 0],linewidth=1,color='blue')
    #ax.plot(contour[:, 1], contour[:, 0],linewidth=2)#,color='r')
    #ellipse = cv.fitEllipse(contour)
#ax.plot(contours[100][:,1], contours[100][:,0],linewidth=2,color='blue')
#ax.axis('off')
#plt.savefig('TestingThresholds\crop228_4.png', bbox_inches='tight', pad_inches=0)
#plt.show())
#plt.show()
#plt.imshow(contours)
#print ("DONE")
#plt.show()
'''
contour = contours[0]

# Create an empty image to store the masked array
r_mask = np.zeros_like(new_image1_mask, dtype='bool')

# Create a contour image by using the contour coordinates rounded to their nearest integer value
r_mask[np.round(contour[:, 0]).astype('int'), np.round(contour[:, 1]).astype('int')] = 1

# Fill in the hole created by the contour boundary
r_mask = ndimage.binary_fill_holes(r_mask)

# Invert the mask since you want pixels outside of the region
r_mask = ~r_mask

ellipse = cv.fitEllipse(r_mask)

plt.imshow(r_mask)
plt.show()

'''





'''
edges = canny(new_image1_mask, sigma=2.0,
              low_threshold=0.55, high_threshold=0.8)


# Perform a Hough Transform
# The accuracy corresponds to the bin size of a major axis.
# The value is chosen in order to get a single high accumulator.
# The threshold eliminates low accumulators
result = hough_ellipse(edges, accuracy=20, threshold=250,
                       min_size=100, max_size=120)
result.sort(order='accumulator')

# Estimated parameters for the ellipse
best = list(result[-1])
yc, xc, a, b = [int(round(x)) for x in best[1:5]]
orientation = best[5]

# Draw the ellipse on the original image
cy, cx = ellipse_perimeter(yc, xc, a, b, orientation)
image_rgb[cy, cx] = (0, 0, 255)
# Draw the edge (white) and the resulting ellipse (red)
edges = color.gray2rgb(img_as_ubyte(edges))
edges[cy, cx] = (250, 0, 0)

fig2, (ax1, ax2) = plt.subplots(ncols=2, nrows=1, figsize=(8, 4), sharex=True,
                                sharey=True,
                                subplot_kw={'adjustable':'box'})

ax1.set_title('Original picture')
ax1.imshow(new_image1_mask)

ax2.set_title('Edge (white) and result (red)')
ax2.imshow(edges)

plt.show()
'''
