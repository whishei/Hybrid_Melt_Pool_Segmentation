# -*- coding: utf-8 -*-
"""
Created on Fri Mar 10 14:02:07 2023

@author: sheilaw
"""

#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial
import seaborn as sns

from skimage import data, color, img_as_ubyte
from skimage.feature import canny
from skimage.transform import hough_ellipse
from skimage.draw import ellipse_perimeter

import cv2 as cv
import scipy.ndimage as ndimage   



new_image_raw1 = Image.open('Files\Test1.png')
new_image1 = new_image_raw1.convert('L')
new_image1 = np.asarray(new_image1)
plt.imshow(new_image1,cmap = plt.cm.gray)
plt.show()

new_image_raw2 = Image.open('Files\Test1_Edits.png')
new_image2 = new_image_raw2.convert('L')
new_image2 = np.asarray(new_image2)
plt.imshow(new_image2,cmap = plt.cm.gray)
plt.show()


new_image1_mask = np.full_like(new_image1,0)
ind = new_image1 == 255
new_image1_mask[ind] = 1
plt.imshow(new_image1_mask,cmap = plt.cm.gray)
plt.show()


new_image2_mask = np.full_like(new_image2,0)
ind = new_image2 == 255
new_image2_mask[ind] = 1
plt.imshow(new_image2_mask,cmap = plt.cm.gray)
plt.show()


newarray = new_image2
test_image = new_image_raw2



im = newarray
distance = ndi.distance_transform_edt(im)
coords = peak_local_max(distance, footprint=np.ones((10, 10)), labels=im)

mask = np.zeros(distance.shape, dtype=bool)
mask[tuple(coords.T)] = True
markers, _ = ndi.label(mask)

#labels = skimage.segmentation.random_walker(im,markers)
labels = skimage.segmentation.watershed(-distance,markers,mask=im)
contours = skimage.measure.find_contours(labels, 3)


my_dpi = 96
#print ("HERE")
fig,ax = plt.subplots(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#ellipses = []
#plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
#ax.imshow(image_raw,cmap = plt.cm.gray)
for contour in contours:
    #ax.plot(contour[0, 1], contour[0, 0],linewidth=1,color='r')
    #ax.plot(contour[1, 1], contour[1, 0],linewidth=1,color='blue')
    ax.plot(contour[:, 1], contour[:, 0],linewidth=2)#,color='r')
    #ellipse = cv.fitEllipse(contour)
#ax.plot(contours[100][:,1], contours[100][:,0],linewidth=2,color='blue')
ax.axis('off')
#plt.savefig('TestingThresholds\crop228_4.png', bbox_inches='tight', pad_inches=0)
#plt.show())
plt.show()


'''
blank = np.full_like(newarray,0)
for i in range(0,len(contours)):
    mask = (np.rint(contours[i])).astype(int)
    if len(mask) >= 10:
        blank[mask[:,0],mask[:,1]] = i
    #new_contours.append(blank)
    
    
    
areas = []
asp = []
cell_threshold = 10
mask = blank#new_contours
for i in range(1,mask.max()+1):
  cell_mask=mask==i
  n_px=cell_mask.sum()
  cell_mask1=cell_mask*255
  i_cont, hierarchy = cv.findContours(cell_mask1,2,1)
  if i_cont != ():
      cont=max(i_cont, key=len)
      cont=cont.reshape(-1,2)
      if len(cont)>=cell_threshold:
        print("cell_"+str(i), "area" + str(n_px))#,"contour" + str(cont))
        areas.append(n_px)
        ellipse = cv.fitEllipse(cont)
        print (ellipse)
        asp.append((ellipse[1][1]+1)/(ellipse[1][0]+1))
        cv.ellipse(test_image,ellipse, (0,0,255), 3)


#cv.imshow(test_image)
#plt.show()
vals, edges = np.histogram(areas,50,range = [0,50])

#middle = []
num = []
for i in range(0,len(edges)-1):
    middle = (edges[i]+ edges[i+1])/2 
    num.append(middle)

plt.hist(vals,bins = num)
#plt.plot(num,vals)
plt.show()
'''
'''
#Creating the second training mask
new_image1_interior = (new_image1 >= 240)
new_image1_boundary = (new_image1 <= 20)
new_image1_80 = (new_image1 <= 140)
new_image1_75 = (new_image1 >= 120)
new_image1_other = np.logical_and(new_image1_80,new_image1_75)

new_image1_mask = np.full(new_image1.shape, -1)
new_image1_mask[new_image1_other] = 1 #119
new_image1_mask[new_image1_interior] = 2 #255
new_image1_mask[new_image1_boundary] = 0

my_dpi = 3600
'''
'''
plt.figure(dpi=my_dpi)
plt.imshow(new_image1_mask,cmap=plt.cm.gray)
plt.colorbar()
plt.axis('off')
plt.savefig('Look.eps', bbox_inches='tight', pad_inches=0)
plt.show()
'''

'''
#Creating the second training mask
new_image2_interior = (new_image2 >= 240)
new_image2_boundary = (new_image2 <= 20)
new_image2_80 = (new_image2 <= 140)
new_image2_75 = (new_image2 >= 120)
new_image2_other = np.logical_and(new_image2_80,new_image2_75)

new_image2_mask = np.full(new_image2.shape, -1)
new_image2_mask[new_image2_other] = 1 #119
new_image2_mask[new_image2_interior] = 2 #255
new_image2_mask[new_image2_boundary] = 0

my_dpi = 3600

plt.figure(dpi=my_dpi)
plt.imshow(new_image2_mask,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('NEEDTOTEST2.eps', bbox_inches='tight', pad_inches=0)
plt.show()
'''

#new_image1_mask = [[-1,-1,2,2],[0,2,2,2],[1,1,2,0],[1,2,2,-1],[1,2,0,2],[2,0,2,0],[2,2,2,2],[2,0,2,0]]
#new_image1_mask = np.array(new_image1_mask)
#PDF Calc

#man_seg = new_image1_mask
'''
mult_k = 100
Ps = []
for k in range (0,108):
    coords = []
    for i in range(0,mult_k):
        length = 0
        for j in range(0,len(man_seg[i+(k*mult_k)])):
            if man_seg[i+(k*mult_k)][j] == 2: #= man_seg[i][j+1]:
                length = length + 1
                if j == len(man_seg[i+(k*mult_k)]) - 1:
                    coords.append(length)
            else:
                if length != 0:
                    coords.append(length)
                length = 0
        #print (i + (k*50))
    vals, edges = np.histogram(coords,50,range = [0,50])
    
    #middle = []
    
    num = []
    for i in range(0,len(edges)-1):
        middle = (edges[i]+ edges[i+1])/2 
        num.append(vals[i]*middle)
    
    
    den = sum(num)
    
    if den == 0:
        P = num 
    else:
        P = num/den   
    Ps.append(P)
    
    #Ps.append(vals)
    #print (k)
    
Ps = np.array(Ps)
#a = np.random.random((16, 16))


#np.save('Horizontal_Distribution.npy',Ps)

fig, ax = plt.subplots(figsize=(1, 5))

#create heatmap
#sns.heatmap(data, linewidths=.3)
#sns.color_palette("Spectral", as_cmap=True)

my_cmap = plt.cm.get_cmap('Spectral')
my_cmap = my_cmap.reversed()
my_cmap.set_over("white")
my_cmap.set_under("white")
plot_1 = sns.heatmap(Ps, yticklabels=False, xticklabels=False, cmap = my_cmap,vmax = 0.06, vmin = 0.001)
#plot_1.set_xlabel('X-Axis', fontsize=10)
plot_1.set_ylabel('P', rotation = 0, fontsize=10)
plt.savefig('Heatmap_new_new.png', bbox_inches='tight', pad_inches=0)
plt.show()
#fig = plot_1.get_figure()
#fig.savefig("out.png", figsize = (1,5))
my_dpi = 3600


plt.figure(dpi = my_dpi, figsize = (1,5))

#plt.imshow(Ps, cmap='hot', interpolation='nearest')
#plt.colorbar()
plt.savefig('Figures/Heatmap.png', bbox_inches='tight', pad_inches=0)
plt.show()
#ax = sns.heatmap(Ps, linewidth=0.5)
#plt.show()
''''''

#Vertical Coord Lengths
man_seg = man_seg.T
mult_k = 100
#plt.imshow(man_seg,cmap=plt.cm.gray)
#plt.colorbar()
#plt.axis('off')
#plt.savefig('Look.eps', bbox_inches='tight', pad_inches=0)
plt.show()

#print (man_seg)
Ps = []
for k in range (0,108):
    coords = []
    for i in range(0,mult_k):
        length = 0
        for j in range(0,len(man_seg[i+(k*mult_k)])):
            if man_seg[i+(k*mult_k)][j] == 2: #== man_seg[i][j+1]:
                length = length + 1
                if j == len(man_seg[i+(k*mult_k)]) - 1:
                    coords.append(length)
            else:
                if length != 0:
                    coords.append(length)
                length = 0
    #print (coords)
    vals, edges = np.histogram(coords,25,range = [0,25])
    
    #Ps.append(vals)
    
    #middle = []
    num = []
    for i in range(0,len(edges)-1):
        middle = (edges[i]+ edges[i+1])/2 
        num.append(vals[i]*middle)
    
    
    den = sum(num)
    #print (vals)
    if den == 0:
        P = num 
    else:
        P = num/den  
    Ps.append(P)
    #print (k)
    

Ps = np.array(Ps)
Ps = Ps.T
#a = np.random.random((16, 16))
np.save('Vertical_Distribution.npy',Ps)
fig, ax = plt.subplots(figsize=(5, 1))

#create heatmap
#sns.heatmap(data, linewidths=.3)
my_cmap = plt.cm.get_cmap('Spectral')
my_cmap = my_cmap.reversed()
my_cmap.set_over("white")
my_cmap.set_under("white")
plot_1 = sns.heatmap(Ps, yticklabels=False, xticklabels=False, cmap = my_cmap,vmax = 0.1, vmin = 0.001)
#plot_1.set_xlabel('X-Axis', fontsize=10)
plot_1.set_xlabel('P', fontsize=10)
plt.savefig('Heatmap_new_new2.png', bbox_inches='tight', pad_inches=0)
plt.show()
#fig = plot_1.get_figure()
#fig.savefig("out.png", figsize = (1,5))
my_dpi = 3600
'''
'''
plt.figure(dpi = my_dpi, figsize = (1,5))

#plt.imshow(Ps, cmap='hot', interpolation='nearest')
#plt.colorbar()
plt.savefig('Heatmap.png', bbox_inches='tight', pad_inches=0)
plt.show()
#ax = sns.heatmap(Ps, linewidth=0.5)
#plt.show()

'''

'''
plot_2 = sns.heatmap(Ps,yticklabels=False, xticklabels=False)
fig = plot_2.get_figure()
fig.savefig("out2.png", figsize = (5,1))

my_dpi = 3600
plt.figure(dpi = my_dpi, figsize = (5,1))

#plt.imshow(Ps, cmap='hot', interpolation='nearest')
#plt.colorbar()
plt.savefig('Heatmap2.png', bbox_inches='tight', pad_inches=0)
plt.show()
#ax = sns.heatmap(Ps, linewidth=0.5)
#plt.show()

my_dpi = 3600

plt.figure(dpi = my_dpi, figsize = (5,1))
plt.imshow(Ps, cmap='hot', interpolation='nearest')
#plt.colorbar()
plt.savefig('Heatmap2.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''

'''
plt.title('Horizontal Coord Lengths of Edited')
plt.hist(coords,250, range=[0,250])
#plt.savefig('Bottom_edited_horizontal_histogram.png', bbox_inches='tight', pad_inches=0)
plt.show()

plt.title('Horizontal Coord Lengths of Edited')
plt.plot(P)
#plt.savefig('Bottom_edited_horizontal_histogram.png', bbox_inches='tight', pad_inches=0)
plt.show()


print ('Done1')
'''
'''
#Horizontal Coord Lengths
man_seg = new_image1_mask
coords = []
for i in range(0,len(man_seg)):
    length = 0
    for j in range(0,len(man_seg[i])):
        if man_seg[i][j] == 2: #== man_seg[i][j+1]:
            length = length + 1
            if j == len(man_seg[i]) - 1:
                coords.append(length)
        else:
            if length != 0:
                coords.append(length)
            length = 0

vals, edges = np.histogram(coords,50,range = [0,50])

#middle = []
num = []
for i in range(0,len(edges)-1):
    middle = (edges[i]+ edges[i+1])/2 
    num.append(vals[i]*middle)


den = sum(num)

P = num/den  

print ('Done1')
plt.title('Horizontal Coord Lengths of Slice 1')
#plt.hist(coords,250, range=[0,250])
plt.plot(P)
plt.savefig('Horizontal_Coord_Lengths_of_Slice_1.png', bbox_inches='tight', pad_inches=0)
plt.show()
#plt.savefig('Bottom_edited_horizontal_histogram.png', bbox_inches='tight', pad_inches=0)
#plt.show()

edit_hz = coords


#Vertical Coord Lengths
man_seg = man_seg.T
#print (man_seg)
coords = []
for i in range(0,len(man_seg)):
    length = 0
    for j in range(0,len(man_seg[i])):
        if man_seg[i][j] == 2: #== man_seg[i][j+1]:
            length = length + 1
            if j == len(man_seg[i]) - 1:
                coords.append(length)
        else:
            if length != 0:
                coords.append(length)
            length = 0

vals, edges = np.histogram(coords,25,range = [0,25])

#middle = []
num = []
for i in range(0,len(edges)-1):
    middle = (edges[i]+ edges[i+1])/2 
    num.append(vals[i]*middle)


den = sum(num)

P = num/den  

plt.title('Vertical Coord Lengths of Slice 1')
#plt.hist(coords,250, range=[0,250])
plt.plot(P)
plt.savefig('Vertical_Coord_Lengths_of_SLice_1.png', bbox_inches='tight', pad_inches=0)
plt.show()
     
print ('Done2')
#plt.title('Vertical Coord Lengths of Edited')
#plt.hist(coords,50,range=[0, 50])
#plt.savefig('Bottom_edited_vertical_histogram.png', bbox_inches='tight', pad_inches=0)
#plt.show()
'''
'''
edit_v = coords


#Horizontal Coord Lengths
man_seg = new_image2_mask
coords = []
for i in range(0,len(man_seg)):
    length = 0
    for j in range(0,len(man_seg[i])):
        if man_seg[i][j] == 2: #== man_seg[i][j+1]:
            length = length + 1
            if j == len(man_seg[i]) - 1:
                coords.append(length)
        else:
            if length != 0:
                coords.append(length)
            length = 0

#plt.title('Horizontal Coord Lengths of RF')
#plt.hist(coords,250,range=[0, 250])
#plt.savefig('Bottom_horizontal_histogram.png', bbox_inches='tight', pad_inches=0)
#plt.show()

vals, edges = np.histogram(coords,250,range = [0,250])

#middle = []
num = []
for i in range(0,len(edges)-1):
    middle = (edges[i]+ edges[i+1])/2 
    num.append(vals[i]*middle)


den = sum(num)

P = num/den  

plt.title('Horizontal Coord Lengths of NotEdited')
#plt.hist(coords,250, range=[0,250])
plt.plot(P)
plt.savefig('Test1_NotEdited_Histogram_HZ.png', bbox_inches='tight', pad_inches=0)
plt.show()

nonedit_hz = coords

print ('Done3')

#Vertical Coord Lengths
man_seg = man_seg.T
#print (man_seg)
coords = []
for i in range(0,len(man_seg)):
    length = 0
    for j in range(0,len(man_seg[i])):
        if man_seg[i][j] == 2: #== man_seg[i][j+1]:
            length = length + 1
            if j == len(man_seg[i]) - 1:
                coords.append(length)
        else:
            if length != 0:
                coords.append(length)
            length = 0
            
#plt.title('Vertical Coord Lengths of RF')
#plt.hist(coords,50, range=[0, 50])
#plt.savefig('Bottom_vertical_histogram.png', bbox_inches='tight', pad_inches=0)
#plt.show()

nonedit_v = coords
vals, edges = np.histogram(coords,50,range = [0,50])

#middle = []
num = []
for i in range(0,len(edges)-1):
    middle = (edges[i]+ edges[i+1])/2 
    num.append(vals[i]*middle)


den = sum(num)

P = num/den  

#print ('Done1')
plt.title('Vertical Coord Lengths of NotEdited')
#plt.hist(coords,250, range=[0,250])
plt.plot(P)
plt.savefig('Test1_NotEdited_Histogram_V.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
'''
print ('Done4')
#Vertical Histograms
fig, ax = plt.subplots(1,2,figsize=(12, 8))
plt.subplot(121)
plot1=plt.hist(nonedit_v,50,range = [0,50])
plt.title("Not Edited Vertical Chord Length")
plt.subplot(122)
plot2=plt.hist(edit_v,50,range = [0,50])
plt.title("Edited Vertical Chord Length")
#plt.savefig('Test1_vertical_histogram_2.png', bbox_inches='tight', pad_inches=0)
plt.show()


diff=plt.bar(np.arange(50), 
             height=(plot1[0]-plot2[0])) 
plt.title("Not Edited - Edited Vertical Chord Length")
#plt.savefig('Test1_vertical_change_histogram.png', bbox_inches='tight', pad_inches=0)
plt.show()


#Vertical Histograms
fig, ax = plt.subplots(1,2,figsize=(12, 8))
plt.subplot(121)
plot1=plt.hist(nonedit_hz,250,range = [0,250])
plt.title("Not Edited Horizontal Chord Length")
plt.subplot(122)
plot2=plt.hist(edit_hz,250,range = [0,250])
plt.title("Edited Horizontal Chord Length")
#plt.savefig('Test1_horizontal_histogram_2.png', bbox_inches='tight', pad_inches=0)
plt.show()


diff=plt.bar(np.arange(250), 
             height=(plot1[0]-plot2[0])) 
plt.title("Not Edited - Edited Horizontal Chord Length")
#plt.savefig('Test1_horizontal_change_histogram.png', bbox_inches='tight', pad_inches=0)
plt.show()

'''
'''
#Horizontal Difference
plt.title('Horizontal Chord Length Difference')
plt.hist(nonedit_hz - edit_hz,250, range=[0, 250])
plt.savefig('Horizontal_Chord_Length_Difference.png', bbox_inches='tight', pad_inches=0)
plt.show()

#Vertical
plt.title('Vertical Chord Length Difference')
plt.hist(nonedit_v - edit_v,50, range=[0, 50])
plt.savefig('Vertical_Chord_Length_Difference.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
