#Testing Filters for segmentation.
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing, opening,erosion
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker
from skimage.measure import regionprops,label

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial


remake_img = np.load('DONTCHANGE.npy')
test_image = remake_img


plt.imshow(remake_img,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('TestingThresholds\Fill.png', bbox_inches='tight', pad_inches=0)
plt.show()


my_dpi = 96

'''
#thresh_value = skimage.filters.threshold_otsu(remake_img)
thresh = remake_img > 0 #thresh_value
#fill = ndi.binary_closing(thresh)
fill = ndi.binary_fill_holes(thresh)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('TestingThresholds\Fill.png', bbox_inches='tight', pad_inches=0)
plt.show()


#thresh_value = skimage.filters.threshold_yen(remake_img)
thresh = remake_img > 0 #thresh_value
fill = ndi.binary_closing(thresh)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('TestingThresholds\Closing.png', bbox_inches='tight', pad_inches=0)
plt.show()

'''
# noise removal
blurred = ndi.gaussian_filter(remake_img,sigma=0.25)#fill, sigma=0.25)
result = hessian(blurred,black_ridges=0,sigmas=1)

# thresholding
threshold = skimage.filters.threshold_otsu(blurred)
binary_image = blurred <= threshold
binary_image = invert(binary_image)

# result visualization
plt.figure(figsize=(test_image.shape[0]/my_dpi,test_image.shape[1]/my_dpi), dpi=my_dpi)#(4452/my_dpi, 19589/my_dpi), dpi=my_dpi)
plt.imshow(binary_image,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Gaus.png', bbox_inches='tight', pad_inches=0)#, dpi = 1000)
plt.show()

element = np.array([[1,0,1],[0,0,0],[1,0,1]]) #[[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])
element2 = np.array([[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])

element3 = np.array([[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])

'''
for i in range (0,2):
    dilate = dilation(erode,element2)
    plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
    plt.imshow(dilate,cmap=plt.cm.gray)
    plt.axis('off')
    name = 'new_' + str(i+2) + '.png'
    plt.savefig(name, bbox_inches='tight', pad_inches=0)
    plt.show()
    erode = dilate


#thresh_value = skimage.filters.threshold_otsu(binary_image)
thresh = binary_image > 0 #thresh_value
fill = ndi.binary_fill_holes(thresh)
plt.figure(figsize=(test_image.shape[0]/my_dpi,test_image.shape[1]/my_dpi), dpi=my_dpi)#figsize=(4452/my_dpi, 19589/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Fill.png', bbox_inches='tight', pad_inches=0)#, dpi = 1000)
plt.show()

fill = fill.astype('int')
interiors = fill == 1
fill[interiors] = 2



dilate = dilation(binary_image,element)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(dilate,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Dilate1.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
#skeleton = skeletonize(fill,method='lee')
erode = erosion(binary_image,element2)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(erode,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Dilate3.png', bbox_inches='tight', pad_inches=0)
plt.show()

'''
#thresh_value = skimage.filters.threshold_otsu(remake_img)
thresh = erode > 0 #thresh_value
#fill = ndi.binary_closing(thresh)
fill = ndi.binary_fill_holes(thresh)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('TestingThresholds\Fill.png', bbox_inches='tight', pad_inches=0)
plt.show()

'''
dilate = dilation(erode,element2)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(dilate,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Dilate1.png', bbox_inches='tight', pad_inches=0)
plt.show()



fill = dilate.astype('int')
interiors = fill == 1
fill[interiors] = 2

background = np.load('Test1_good.npy')
other = fill

back = background == 1
other[back] = 1

plt.imshow(background ,cmap=plt.cm.gray)
plt.colorbar()
plt.show()


plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(other,cmap=plt.cm.gray)
plt.axis('off')
plt.savefig('NEWMASK.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
outside = remake_img == 1
fill[outside] = 1
plt.figure(figsize=(test_image.shape[0]/my_dpi,test_image.shape[1]/my_dpi), dpi=my_dpi)#figsize=(4452/my_dpi, 19589/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('CurrentOutput\Seg_mask.png', bbox_inches='tight', pad_inches=0)#, dpi = 1000)
plt.show()

'''

'''
thresh_value = skimage.filters.threshold_triangle(remake_img)
thresh = remake_img > 1 #thresh_value
fill = ndi.binary_fill_holes(thresh)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
plt.savefig('TestingThresholds\Triangle.png', bbox_inches='tight', pad_inches=0)
plt.show()

'''

#Trying to clean image for better contours 

'''

fill = skimage.morphology.remove_small_objects(fill)#binary_image)
plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
plt.imshow(fill,cmap=plt.cm.gray)
plt.axis('off')
#lt.savefig('Testing.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
