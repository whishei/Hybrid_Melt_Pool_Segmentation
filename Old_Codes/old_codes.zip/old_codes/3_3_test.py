import numpy as np
import pandas as pd
import pickle
import matplotlib.pyplot as plt


background = np.load('Test1_good.npy')
other = np.load('Test1_better.npy')


back = background == 1
other[back] = 1

plt.imshow(background ,cmap=plt.cm.gray)
plt.colorbar()
plt.show()


plt.imshow(other ,cmap=plt.cm.gray)
plt.colorbar()
plt.show()
