#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing,erosion
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial


remake_img = np.load('FullBottom.npy')
test_img = remake_img
test_image = remake_img
print (test_img.shape)
image2 = np.load('FullBottom2.npy')
my_dpi = 3600
'''
image_raw = Image.open('FullBottom_Edits.tif')
image = image_raw.convert('L')
image = np.asarray(image)
plt.imshow(image,cmap=plt.cm.gray)
plt.show()

'''
'''
# noise removal
blurred = ndi.gaussian_filter(remake_img,sigma=0.25)#fill, sigma=0.25)
result = hessian(blurred,black_ridges=0,sigmas=1)

# thresholding
threshold = skimage.filters.threshold_otsu(blurred)
binary_image = blurred <= threshold
binary_image = invert(binary_image)

# result visualization
plt.figure(figsize=(test_image.shape[0]/my_dpi,test_image.shape[1]/my_dpi), dpi=my_dpi)#(4452/my_dpi, 19589/my_dpi), dpi=my_dpi)
plt.imshow(binary_image,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Gaus.png', bbox_inches='tight', pad_inches=0)#, dpi = 1000)
plt.show()

element = np.array([[1,0,1],[0,0,0],[1,0,1]]) #[[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])
element2 = np.array([[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])

element3 = np.array([[1,0,0,1],[0,0,0,0],[0,0,0,0],[1,0,0,1]])

#skeleton = skeletonize(fill,method='lee')
erode = erosion(binary_image,element2)
plt.figure(figsize=(test_image.shape[0]/my_dpi,test_image.shape[1]/my_dpi), dpi=my_dpi)
plt.imshow(erode,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Dilate3.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
'''
dilate = dilation(erode,element2)
plt.figure(figsize=(test_image.shape[0]/my_dpi,test_image.shape[1]/my_dpi), dpi=my_dpi)
plt.imshow(dilate,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('Dilate1.png', bbox_inches='tight', pad_inches=0)
plt.show()
'''
'''
for i in range (0,2):
    dilate = dilation(erode,element)
    plt.figure(figsize=(1000/my_dpi, 1000/my_dpi), dpi=my_dpi)
    plt.imshow(dilate,cmap=plt.cm.gray)
    plt.axis('off')
    name = 'new_' + str(i+2) + '.png'
    #plt.savefig(name, bbox_inches='tight', pad_inches=0)
    plt.show()
    erode = dilate

'''

dilate = test_img
fill = dilate.astype('int')
interiors = fill == 1
fill[interiors] = 2

background = image2
other = fill

back = background == 1
other[back] = 1

plt.imshow(background ,cmap=plt.cm.gray)
plt.colorbar()
plt.show()


plt.figure(dpi = my_dpi)
plt.imshow(other,cmap=plt.cm.gray)
plt.axis('off')
#plt.savefig('HardRegion_Test.eps', bbox_inches='tight', pad_inches=0)
plt.show()

#Horizontal Coord Length
#erode = erode.astype('int')

man_seg = other #background
coords = []
for i in range(0,len(man_seg)):
    length = 0
    for j in range(0,len(man_seg[i])-1):
        if man_seg[i][j] == man_seg[i][j+1]:
            length = length + 1
        else:
            if length != 0:
                coords.append(length)
            length = 0

plt.title('Horizontal Chord Lengths of Segmented Bottom Region')
plt.hist(coords,1000)
plt.savefig('RF_seg_Hz.png', bbox_inches='tight', pad_inches=0)
plt.show()
print (max(coords))

man_seg = man_seg.T
coords = []
for i in range(0,len(man_seg)):
    length = 0
    for j in range(0,len(man_seg[i])-1):
        if man_seg[i][j] == man_seg[i][j+1]:
            length = length + 1
        else:
            if length != 0:
                coords.append(length)
            length = 0

plt.title('Vertical Chord Lengths of Segmented Bottom Region')
plt.hist(coords,1000)
plt.savefig('RF_seg_V.png', bbox_inches='tight', pad_inches=0)
plt.show()
print (max(coords))
