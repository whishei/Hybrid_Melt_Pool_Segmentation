#UTEP Project
import numpy as np
import skimage
from PIL import Image
from skimage.feature import canny, blob_dog, peak_local_max

from skimage.util import invert
from skimage import data
from skimage import color
from skimage.filters import meijering, sato, frangi, hessian
from skimage.morphology import skeletonize, thin, dilation, disk,closing
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from skimage.segmentation import random_walker

from skimage.filters.rank import median 
from skimage import segmentation, feature, future
from sklearn.ensemble import RandomForestClassifier
from functools import partial
import pickle

with open('crop1.pkl', 'rb') as f:
    train1_features = pickle.load(f)

with open('crop88.pkl', 'rb') as f:
    train2_features = pickle.load(f)

with open('Hard_Region.pkl', 'rb') as f:
    train3_features = pickle.load(f)

with open('crop393.pkl', 'rb') as f:
    train4_features = pickle.load(f)



